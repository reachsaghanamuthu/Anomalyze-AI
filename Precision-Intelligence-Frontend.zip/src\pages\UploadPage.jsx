import { useNavigate } from "react-router-dom";
import DataIngestionCard from "../components/DataIngestionCard";
import { useAppState } from "../state/AppContext";

export default function UploadPage() {
  const { selectedFile, setSelectedFile, runAnalysis, isAnalyzing } = useAppState();
  const navigate = useNavigate();

  const handleAnalyze = async () => {
    await runAnalysis();
    navigate("/results");
  };

  return (
    <div className="space-y-5">
      <header>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Upload Data</h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Upload a CSV file and run anomaly detection.
        </p>
      </header>

      <DataIngestionCard
        selectedFile={selectedFile}
        onFileChange={setSelectedFile}
        onAnalyze={handleAnalyze}
        isAnalyzing={isAnalyzing}
        analyzeLabel="Analyze"
      />

      <section className="rounded-2xl border border-slate-200 bg-white p-5 text-sm text-slate-600 shadow-soft dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
        <p>
          Selected file:{" "}
          <span className="font-semibold text-slate-900 dark:text-slate-100">
            {selectedFile?.name || "No file selected"}
          </span>
        </p>
      </section>
    </div>
  );
}
