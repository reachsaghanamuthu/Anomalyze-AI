import { BarChart3, Clock3, FileUp, Home, PlusCircle } from "lucide-react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAppState } from "../state/AppContext";

const menuItems = [
  { label: "Home", path: "/", icon: Home },
  { label: "Upload Data", path: "/upload", icon: FileUp },
  { label: "Results", path: "/results", icon: BarChart3 },
  { label: "History", path: "/history", icon: Clock3 }
];

const linkClasses = ({ isActive }) =>
  `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition ${
    isActive
      ? "bg-brand-600 text-white shadow-soft"
      : "text-slate-600 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
  }`;

export default function Sidebar() {
  const { resetAnalysis } = useAppState();
  const navigate = useNavigate();

  return (
    <aside className="flex h-screen w-72 flex-col border-r border-slate-200 bg-white px-5 py-6 dark:border-slate-800 dark:bg-slate-900">
      <div className="mb-8">
        <p className="text-xs font-bold uppercase tracking-[0.14em] text-brand-600 dark:text-brand-500">
          Precision Intelligence
        </p>
        <h1 className="mt-2 text-xl font-bold text-slate-900 dark:text-slate-50">
          AI Forecast Platform
        </h1>
      </div>

      <nav className="flex-1 space-y-1">
        {menuItems.map(({ label, path, icon: Icon }) => (
          <NavLink key={path} to={path} className={linkClasses} end={path === "/"}>
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>

      <button
        type="button"
        onClick={() => {
          resetAnalysis();
          navigate("/");
        }}
        className="mt-6 flex items-center justify-center gap-2 rounded-xl bg-brand-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-brand-700"
      >
        <PlusCircle size={17} />
        New Analysis
      </button>
    </aside>
  );
}
