import { BarChart3, Clock3, FileUp, Home } from "lucide-react";
import { NavLink } from "react-router-dom";

const navItems = [
  { label: "Home", path: "/", icon: Home },
  { label: "Upload", path: "/upload", icon: FileUp },
  { label: "Results", path: "/results", icon: BarChart3 },
  { label: "History", path: "/history", icon: Clock3 }
];

export default function MobileNav() {
  return (
    <nav className="grid grid-cols-4 gap-2 border-b border-slate-200 bg-white px-3 pb-3 lg:hidden dark:border-slate-800 dark:bg-slate-900">
      {navItems.map(({ label, path, icon: Icon }) => (
        <NavLink
          key={path}
          to={path}
          end={path === "/"}
          className={({ isActive }) =>
            `flex flex-col items-center rounded-lg px-2 py-2 text-[11px] font-semibold ${
              isActive
                ? "bg-brand-600 text-white"
                : "text-slate-600 dark:text-slate-300"
            }`
          }
        >
          <Icon size={16} />
          <span className="mt-1">{label}</span>
        </NavLink>
      ))}
    </nav>
  );
}
