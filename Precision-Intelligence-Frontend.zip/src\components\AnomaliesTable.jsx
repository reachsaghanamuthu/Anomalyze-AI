const statusStyles = {
  Normal:
    "bg-slate-50 text-slate-600 dark:bg-slate-800/60 dark:text-slate-300",
  Abnormal: "bg-red-50 text-red-700 dark:bg-red-500/20 dark:text-red-300",
  Spike: "bg-orange-50 text-orange-700 dark:bg-orange-500/20 dark:text-orange-300"
};

const severityStyles = {
  Low: "text-brand-600 dark:text-brand-400",
  Moderate: "text-orange-600 dark:text-orange-400",
  Critical: "text-red-600 dark:text-red-400"
};

export default function AnomaliesTable({ anomalies }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900">
      <h2 className="mb-4 text-lg font-semibold text-slate-900 dark:text-slate-100">
        Detected Anomalies
      </h2>
      <div className="overflow-x-auto">
        <table className="min-w-full border-separate border-spacing-y-2 text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-slate-500">
              <th className="px-3 py-2 font-semibold">Timestamp</th>
              <th className="px-3 py-2 font-semibold">Value</th>
              <th className="px-3 py-2 font-semibold">Status</th>
              <th className="px-3 py-2 font-semibold">Severity</th>
              <th className="px-3 py-2 font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {anomalies.map((item, index) => (
              <tr
                key={`${item.timestamp}-${index}`}
                className="rounded-xl bg-slate-50 dark:bg-slate-800/40"
              >
                <td className="rounded-l-xl px-3 py-3 text-slate-700 dark:text-slate-200">
                  {item.timestamp}
                </td>
                <td className="px-3 py-3 font-semibold text-slate-800 dark:text-slate-100">
                  {item.value}
                </td>
                <td className="px-3 py-3">
                  <span
                    className={`inline-flex rounded-lg px-3 py-1 text-xs font-bold ${
                      statusStyles[item.status] || statusStyles.Normal
                    }`}
                  >
                    {item.status}
                  </span>
                </td>
                <td className="px-3 py-3">
                  <span
                    className={`font-semibold ${
                      severityStyles[item.severity] || severityStyles.Low
                    }`}
                  >
                    {item.severity}
                  </span>
                </td>
                <td className="rounded-r-xl px-3 py-3">
                  <button
                    type="button"
                    className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    Review
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
