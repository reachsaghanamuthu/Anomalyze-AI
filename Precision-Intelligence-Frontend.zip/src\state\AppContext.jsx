import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { buildDummyPayload } from "../data/mockData";
import { analyzeDataWithFallback } from "../services/analysisService";

const AppContext = createContext(null);

const sampleValues = [10, 12, 11, 13, 50];

export const AppProvider = ({ children }) => {
  const [theme, setTheme] = useState("light");
  const [selectedFile, setSelectedFile] = useState(null);
  const [analysis, setAnalysis] = useState(buildDummyPayload());
  const [history, setHistory] = useState([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  const resetAnalysis = () => {
    setSelectedFile(null);
    setAnalysis(buildDummyPayload());
  };

  const runAnalysis = async (file) => {
    setIsAnalyzing(true);
    const nextFile = file || selectedFile;
    const fileName = nextFile?.name || "manual-entry.csv";

    try {
      const result = await analyzeDataWithFallback({
        values: sampleValues,
        fileName
      });
      setAnalysis(result);
      setHistory((prev) => [
        {
          id: crypto.randomUUID(),
          fileName,
          analyzedAt: new Date().toLocaleString(),
          anomalies: result.metrics?.totalAnomalies ?? result.anomalies?.length ?? 0,
          confidence: result.metrics?.modelConfidence ?? "N/A"
        },
        ...prev
      ]);
      return result;
    } finally {
      setIsAnalyzing(false);
    }
  };

  const value = useMemo(
    () => ({
      theme,
      toggleTheme,
      selectedFile,
      setSelectedFile,
      analysis,
      runAnalysis,
      history,
      isAnalyzing,
      resetAnalysis
    }),
    [analysis, history, isAnalyzing, selectedFile, theme]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppState = () => {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error("useAppState must be used inside AppProvider");
  }
  return ctx;
};
