# Precision Intelligence - AI Forecast & Anomaly Detection Platform

Modern React dashboard for forecasting and anomaly detection with:

- React functional components
- Tailwind CSS
- Recharts
- React Router
- Dark/light global theme
- API-ready analyze flow with webhook + fallback dummy simulation

## Run

```bash
npm install
npm start
```

Default Vite URL:

```text
http://localhost:5173
```

## Routes

- `/` Home dashboard
- `/upload` Upload Data
- `/results` Results
- `/history` History

## Notes

- `Analyze Data` and `Analyze` trigger async analysis.
- Webhook defaults:
  - Dev (`npm start`): `https://varsha25.app.n8n.cloud/webhook-test/analyze-data`
  - Production build: `https://varsha25.app.n8n.cloud/webhook/analyze-data`
- You can override endpoint with `VITE_N8N_WEBHOOK_URL` in `.env`.
- If webhook is unavailable, it falls back to realistic dummy data.
