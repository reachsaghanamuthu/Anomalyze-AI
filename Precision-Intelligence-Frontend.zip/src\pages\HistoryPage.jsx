import { useAppState } from "../state/AppContext";

export default function HistoryPage() {
  const { history } = useAppState();

  return (
    <div className="space-y-5">
      <header>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
          Analysis History
        </h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Review previous forecasting and anomaly detection runs.
        </p>
      </header>

      <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-soft dark:border-slate-800 dark:bg-slate-900">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500 dark:bg-slate-800/60">
            <tr>
              <th className="px-4 py-3">File</th>
              <th className="px-4 py-3">Analyzed At</th>
              <th className="px-4 py-3">Anomalies</th>
              <th className="px-4 py-3">Confidence</th>
            </tr>
          </thead>
          <tbody>
            {history.length === 0 ? (
              <tr>
                <td
                  colSpan={4}
                  className="px-4 py-10 text-center text-slate-500 dark:text-slate-400"
                >
                  No analyses yet. Run a new analysis from Home or Upload Data.
                </td>
              </tr>
            ) : (
              history.map((item) => (
                <tr
                  key={item.id}
                  className="border-t border-slate-100 dark:border-slate-800"
                >
                  <td className="px-4 py-3 font-semibold text-slate-700 dark:text-slate-200">
                    {item.fileName}
                  </td>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                    {item.analyzedAt}
                  </td>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                    {item.anomalies}
                  </td>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                    {item.confidence}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}
