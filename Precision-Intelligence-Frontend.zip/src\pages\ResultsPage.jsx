import { Brain, ShieldAlert, TrendingUp } from "lucide-react";
import MetricCard from "../components/MetricCard";
import TrendChart from "../components/TrendChart";
import { useAppState } from "../state/AppContext";

export default function ResultsPage() {
  const { analysis } = useAppState();

  return (
    <div className="space-y-6">
      <header className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Results</h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Source: {analysis.source} • Generated at:{" "}
          {new Date(analysis.generatedAt).toLocaleString()}
        </p>
      </header>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <MetricCard
          title="Prediction Trend"
          value={analysis.metrics.predictionTrend}
          icon={TrendingUp}
          helper="Compared to historical baseline"
        />
        <MetricCard
          title="Total Anomalies"
          value={analysis.metrics.totalAnomalies}
          icon={ShieldAlert}
          helper="Across the analyzed timeline"
        />
        <MetricCard
          title="Model Confidence"
          value={analysis.metrics.modelConfidence}
          icon={Brain}
          helper="Confidence in current forecast"
        />
      </section>

      <TrendChart data={analysis.trendData} />

      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900">
        <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
          AI Insights
        </h3>
        <ul className="mt-4 space-y-2 text-sm text-slate-600 dark:text-slate-300">
          {analysis.insights?.map((item, index) => (
            <li
              key={index}
              className="rounded-lg bg-slate-50 px-3 py-2 dark:bg-slate-800/50"
            >
              {item}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
