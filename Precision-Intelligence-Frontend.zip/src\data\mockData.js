const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export const buildDummyPayload = (fileName = "demo-data.csv") => ({
  source: fileName,
  generatedAt: new Date().toISOString(),
  metrics: {
    predictionTrend: "+12.4%",
    totalAnomalies: 32,
    modelConfidence: "98.2%"
  },
  trendData: [
    { point: "09:00", historical: 10, forecast: null },
    { point: "10:00", historical: 12, forecast: null },
    { point: "11:00", historical: 11, forecast: null },
    { point: "12:00", historical: 13, forecast: 14 },
    { point: "13:00", historical: null, forecast: 17 },
    { point: "14:00", historical: null, forecast: 20 },
    { point: "15:00", historical: null, forecast: 18 }
  ],
  anomalies: [
    {
      timestamp: "2026-04-27 09:45",
      value: 11,
      status: "Normal",
      severity: "Low"
    },
    {
      timestamp: "2026-04-27 11:20",
      value: 27,
      status: "Abnormal",
      severity: "Moderate"
    },
    {
      timestamp: "2026-04-27 12:05",
      value: 50,
      status: "Spike",
      severity: "Critical"
    },
    {
      timestamp: "2026-04-27 14:10",
      value: 16,
      status: "Normal",
      severity: "Low"
    }
  ],
  insights: [
    "Forecast indicates continued growth over the next three intervals.",
    "A high-severity spike was detected near 12:05 and should be reviewed.",
    "Model confidence remains stable above 98% for this dataset."
  ]
});

export const simulateAnalyze = async (fileName) => {
  await delay(1200);
  return buildDummyPayload(fileName);
};
