import { simulateAnalyze } from "../data/mockData";

const N8N_TEST_ENDPOINT =
  "https://varsha25.app.n8n.cloud/webhook-test/analyze-data";
const N8N_PROD_ENDPOINT =
  "https://varsha25.app.n8n.cloud/webhook/analyze-data";

const DEFAULT_ENDPOINT = import.meta.env.DEV
  ? N8N_TEST_ENDPOINT
  : N8N_PROD_ENDPOINT;
const ENDPOINT = import.meta.env.VITE_N8N_WEBHOOK_URL || DEFAULT_ENDPOINT;

export const analyzeDataWithFallback = async ({ values, fileName }) => {
  try {
    const res = await fetch(ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        values,
        fileName
      })
    });

    if (!res.ok) {
      throw new Error("Webhook request failed");
    }

    const data = await res.json();
    return {
      ...data,
      source: fileName || data.source || "uploaded.csv",
      generatedAt: data.generatedAt || new Date().toISOString()
    };
  } catch (error) {
    return simulateAnalyze(fileName);
  }
};
