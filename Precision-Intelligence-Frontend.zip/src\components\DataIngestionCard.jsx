import { UploadCloud } from "lucide-react";
import { useRef, useState } from "react";

export default function DataIngestionCard({
  selectedFile,
  onFileChange,
  onAnalyze,
  isAnalyzing,
  analyzeLabel = "Analyze Data"
}) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef(null);

  const applyFile = (file) => {
    if (file && file.name.toLowerCase().endsWith(".csv")) {
      onFileChange(file);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    applyFile(e.dataTransfer.files?.[0]);
  };

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-800 dark:bg-slate-900">
      <div
        className={`rounded-xl border-2 border-dashed p-8 text-center transition ${
          isDragging
            ? "border-brand-600 bg-brand-50 dark:bg-slate-800"
            : "border-slate-300 bg-slate-50 dark:border-slate-700 dark:bg-slate-800/40"
        }`}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={onDrop}
      >
        <UploadCloud className="mx-auto mb-3 text-brand-600" />
        <p className="text-sm font-medium text-slate-700 dark:text-slate-200">
          Drag and drop CSV files here
        </p>
        <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
          {selectedFile ? `Selected: ${selectedFile.name}` : "or choose a CSV file manually"}
        </p>
        <button
          type="button"
          className="mt-4 rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-100 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-700"
          onClick={() => fileInputRef.current?.click()}
        >
          Choose File
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          className="hidden"
          onChange={(e) => applyFile(e.target.files?.[0])}
        />
      </div>

      <button
        type="button"
        onClick={onAnalyze}
        disabled={isAnalyzing}
        className="mt-4 w-full rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-70"
      >
        {isAnalyzing ? "Analyzing..." : analyzeLabel}
      </button>
    </section>
  );
}
