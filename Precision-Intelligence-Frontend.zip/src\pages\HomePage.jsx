import { Brain, ShieldAlert, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import AnomaliesTable from "../components/AnomaliesTable";
import DataIngestionCard from "../components/DataIngestionCard";
import MetricCard from "../components/MetricCard";
import TrendChart from "../components/TrendChart";
import { useAppState } from "../state/AppContext";

export default function HomePage() {
  const { selectedFile, setSelectedFile, runAnalysis, analysis, isAnalyzing } = useAppState();
  const navigate = useNavigate();

  const handleAnalyze = async () => {
    await runAnalysis();
    navigate("/results");
  };

  return (
    <div className="space-y-6">
      <DataIngestionCard
        selectedFile={selectedFile}
        onFileChange={setSelectedFile}
        onAnalyze={handleAnalyze}
        isAnalyzing={isAnalyzing}
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <MetricCard
          title="Prediction Trend"
          value={analysis.metrics.predictionTrend}
          icon={TrendingUp}
          helper="Forecast uplift compared to baseline"
        />
        <MetricCard
          title="Total Anomalies"
          value={analysis.metrics.totalAnomalies}
          icon={ShieldAlert}
          helper="Flagged events in latest run"
        />
        <MetricCard
          title="Model Confidence"
          value={analysis.metrics.modelConfidence}
          icon={Brain}
          helper="Current confidence from model output"
        />
      </section>

      <TrendChart data={analysis.trendData} />
      <AnomaliesTable anomalies={analysis.anomalies} />
    </div>
  );
}
